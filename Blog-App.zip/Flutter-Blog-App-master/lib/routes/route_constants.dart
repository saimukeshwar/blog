class RouteConstant {
  static const String ROOT = '/';
  static const String ADD_POST = '/add-post';
  static const String EDIT_POST = '/edit-post';
  static const String VIEW_POST = '/view-post';
  static const String ABOUT = '/about';
  static const String MEDIUM_ARTICLES = '/medium-articles';
  static const String MEDIUM_ARTICLES_WEB_VIEW = '/medium-article-web-view';
}